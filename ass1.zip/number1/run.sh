#!/bin/bash

#move into the directory of the mast
#cd Home/mo/MO_1/sources
#gcc master.c -o master

#executes the master
konsole -e master &
konsole -e Command &
konsole -e Inspection

#move back into the main directory
#cd ..
#cd ..
