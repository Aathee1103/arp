// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/wait.h>

// Defining some colors

pid_t pid_motor_x;
pid_t pid_motor_z;
pid_t pid_watchdog;
pid_t pid_command;
float x, z;

void reset(){
    x =0, z = 0;
    kill(pid_motor_x, SIGUSR2);
    kill(pid_motor_z, SIGUSR2);
    kill(pid_watchdog, SIGUSR1);
    kill(pid_command, SIGUSR2);
    
    
 
    printf("\nStopped motors and resetted position ..\n"); fflush(stdout);
}


//Function to stop motors
void stop(){
     kill(pid_motor_x, SIGUSR1);
    kill(pid_motor_z, SIGUSR1);
    kill(pid_watchdog, SIGUSR1);
    kill(pid_command, SIGUSR1);
    
    
   
    printf("\nStopped motors ..\n"); fflush(stdout);
}

//Function to handle SIGUSR1 signal from the watchdog and do the reset procedure
/*void handle_sigusr1(int sig){
    reset();
   
    printf("\nInactive from 60 seconds! -> Resetted positions and stopped motors\n"); fflush(stdout);
} */
// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.



// Main in which we developed the principal code of the command console.

int main(int argc, char* argv[]){

	// Thanks to these lines of code we can report on the file.txt (logfile.txt) 
	// all the operations we have done. The logfile.txt is created in the master process, in fact
	// there is the append inside the function fopen() that is not "a" like in every other process, but "w"-->
	// Creates an empty file for writing. If a file with the same name already exists, 
	// its content is erased and the file is considered as a new empty file. Whereas in other processes there is the append "a"-->
	// Appends to a file. Writing operations, append data at the end of the file. 
	// The file is created if it does not exist. 
	// We can "concatenate" all the things we do in every single process, reporting them in the logfile.txt, thanks
	// to the "a" append.

	// // Just some aesthetic stuffs.
	printf("This is the Inspection Console, please press:\n");
	printf("Q : to STOP the hoist.\n");
	printf("R : to RESET its position (to 0)\n");

	// We had put this structure code just to avoid pressing 
	// "Enter" every time we want to increase/decrease x and z of our joist
	// The tcgetattr() function will get the parameters associated with 
    // the terminal referred to by the first argument and store them in 
    // the termios structure referenced by the second argument.

	


	// declaration of needed variables 
	
	char ch;

	// Declaring PIDs used for sending Signals


	
	// Declaring int for pipes.

	int fd_from_mx;
	int fd_from_mz;
	int fd_from_comm;
	int retval;
	int maxfd;
	int waiting = 0;
        struct timeval tv={0,0};
	fd_set rdset;
	
	// pipes opening 
	 
    if ((fd_from_mx = open("/tmp/posmotor_x", O_RDONLY)) < 0) {
        perror("Error opening pos x ");
        return 1;
    }
    if ((fd_from_mz = open("/tmp/posmotor_z", O_RDONLY)) < 0) {
        perror("Error opening pos z ");
        return 1;
    }
    if ((fd_from_comm = open("/tmp/comm_ins", O_RDONLY)) < 0) {
        perror("Error opening pos z ");
        return 1;
    }
	// We convert the watchdog's pid thanks to atoi--> from string to integer
	// argv[2/3/4] are the third/fourth/fifth arguments passed to the main from the master process (see master process
	// for detailed explenation) 
	
	pid_motor_x = atoi(argv[2]);
	pid_motor_z = atoi(argv[3]);
	pid_watchdog = atoi(argv[4]);
        //kill(pid_watchdog,SIGUSR1);
	// read the pid command in the Inspection console to send Signal to the Command Console

	read(fd_from_comm, &pid_command, sizeof(pid_command));

	while(1){
		
	

		// select() allows a program to monitor multiple file descriptors,
        // waiting until one or more of the file descriptors become "ready"
        // for some class of I/O operation (e.g., input possible). A file
        // descriptor is considered ready if it is possible to perform a
        // corresponding I/O operation without blocking.

	    // This macro clears (removes all file descriptors from) set.
        // It should be employed as the first step in initializing a
        // file descriptor set.

        FD_ZERO(&rdset);

		// This macro clears (removes all file descriptors from) set.
        // It should be employed as the first step in initializing a
        // file descriptor set.
		
		FD_SET(fd_from_mx, &rdset);
		FD_SET(fd_from_mz, &rdset);
		
		FD_SET(0,&rdset);
		
		// we want to read instantly the datas from motors 
	
		tv.tv_sec = 0;
		tv.tv_usec = 0;

		// The principal arguments of select() are three "sets" of file
        // descriptors (declared with the type fd_set), which allow the
        // caller to wait for three classes of events on the specified set
        // of file descriptors. Each of the fd_set arguments may be
        // specified as NULL if no file descriptors are to be watched for
        // the corresponding class of events. So thanks to the select() we can
		// handle the flows of datas to be read.
		
		retval = select(FD_SETSIZE, &rdset, NULL, NULL, &tv);
		
		if (retval == -1){

			perror("select()");
		}
		
		// select() modifies the contents of the sets according to
        // the rules described below. After calling select(), the
        // FD_ISSET() macro can be used to test if a file descriptor
        // is still present in a set. FD_ISSET() returns nonzero if
        // the file descriptor fd is present in set, and zero if it
        // is not.

		else if (retval >=0){
			
			if(FD_ISSET(fd_from_mx, &rdset) != 0){

				// reading datas directly from motors

				read(fd_from_mx, &x, sizeof(x));
			}
			
			if(FD_ISSET(fd_from_mz, &rdset) != 0){

				read(fd_from_mz, &z, sizeof(z));
			}
			
		}
		
		if (FD_ISSET(0,&rdset)>0){
			read(0, &ch, sizeof(char));
		
			// we now handle the Emergency Buttons

		 
                if (ch =='S' || ch=='s'){
                    stop();
                } else if (ch =='R' || ch =='r'){
                    reset();
                    
                }
            }
		
		
		// If the reset is completed, the Command Console will be able to work again. All these instructions
		// are handled by the "l" flag at the beginning of the command.c
           if (x == 0 && z == 0){

			kill(pid_command, SIGUSR1);	
		}
		
		
		
		printf("\rX position: %f meter, Z position: %f meter", x, z);
		fflush(stdout);

		// The flow of datas "printed" on the logfile.txt is extremely big. So we can reduce it using this
		// waiting variable

		
		
	}
	
	
	
	// Closing pipes

	close(fd_from_mx);
	close(fd_from_mz);
	close(fd_from_comm);
	
	return 0;
}
	
	
