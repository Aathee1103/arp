// Including all the needed libraries.

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>  
#include <signal.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/wait.h>

// Defining some colors.

 

// The CHECK(X) function is usefull to write on shell whenever a system call return an error.
// The function will print the name of the file and the line at which it found the error.
// It will end the check exiting with code 1.

// In this part of the code we use the handler() function in order
// to handle Signals coming from different processes. Like so we can disable
// the Command Console during the reset procedure and restart it once it finished the 
// reset routine. 

int l = 0;

void handler(int sig){

	if(sig == SIGUSR2){
		
		// System is resetting

		l = 1;
		printf( "\nSYSTEM RESETTING! \n");
	}

	if(sig == SIGUSR1){

		// System able to work again

		l = 0;
	}
} 

// Main in which we developed the principal code of the Command Console.

int main(int argc, char *argv[]){

	// Thanks to these lines of code we can report on the file.txt (logfile.txt) 
	// all the operations we have done. The logfile.txt is created in the master process, in fact
	// there is the append inside the function fopen() that is not "a" like in every other process, but "w"-->
	// Creates an empty file for writing. If a file with the same name already exists, 
	// its content is erased and the file is considered as a new empty file. Whereas in other processes there is the append "a"-->
	// Appends to a file. Writing operations, append data at the end of the file. 
	// The file is created if it does not exist. 
	// We can "concatenate" all the things we do in every single process, reporting them in the logfile.txt, thanks
	// to the "a" append.

	
	// We had put this structure code just to avoid pressing 
	// "Enter" every time we want to increase/decrease x and z of our joist
	// The tcgetattr() function will get the parameters associated with 
    // the terminal referred to by the first argument and store them in 
    // the termios structure referenced by the second argument.



	// Setting the current time. This is very usefull since we can report on the logfile.txt the 
	// exact time we have done a particular operation

	
    struct timeval tv={0,0};
     
	// Just some aesthetic stuffs.
    printf("COMMAND CONSOLE, please press the required commands to perform the operations\n");
    printf("\n");
    printf("To move UP, please press W\n");
    printf("To move DOWN, please press S\n");
    printf("To move RIGHT, please press D\n");
    printf("To move LEFT, please press A\n");
    printf("To STOP z axis, please press Z\n");
    printf("To STOP x axis, please press X\n");
	printf("Press E if you want to terminate programs execution\n");
    printf("\n");
	
    //disable_waiting_for_enter();
  
	// In this part we have declared some varibales usefull in the code.

	// Declaring int for pipes.

    int fd_to_mx;
    int fd_to_mz;
    int fd_to_wd;
	int fd_to_insp;

	// Declaring variables used for select().

    int d = 1;
    int a = 2;
    int w = 3;
    int s = 4;
    int x = 5;
    int z = 6;
    
	// Declaring pid of watchdog and command.

    pid_t pid_wd;
    pid_t pid_command;
    
    char ch;
    
	// Declaring for the use of Signals.

    struct sigaction sa; 
    
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler=&handler;
    sa.sa_flags=SA_RESTART;
    sigaction(SIGUSR2, &sa, NULL);
    sigaction(SIGUSR1, &sa, NULL);

	// We convert the watchdog's pid thanks to atoi--> from string to integer
	// argv[1] is the second argument passed to the main from the master process (see master process
	// for detailed explenation)
    
    pid_wd = atoi(argv[1]);

	// Getting pid of the command, sending it to watchdog and inspection
	// just for using Signals.

    pid_command = getpid();
    
    // opens pipes to write the commands 
    if ((fd_to_mx = open("/tmp/command_x", O_WRONLY)) < 0) {
        perror("Error opening cmd x ");
        return 1;
    }
    if ((fd_to_mz = open("/tmp/command_z", O_WRONLY)) < 0) {
        perror("Error opening cmd z ");
        return 1;
    }
    if ((fd_to_wd = open("/tmp/cwd", O_WRONLY)) < 0) {
        perror("Error opening cmd x ");
        return 1;
    }
    if ((fd_to_insp = open("/tmp/comm_ins", O_WRONLY)) < 0) {
        perror("Error opening cmd z ");
        return 1;
      }
	// Writing command pid to watchdog and inspection

    write(fd_to_wd, &pid_command, sizeof(pid_command));
	write(fd_to_insp, &pid_command, sizeof(pid_command));
	

	// Key reading loop: entering the loop of putting char from keyboard, without exit from program (no return in infinite while loop) 
	
	while ((ch = getchar()) != 'e'){

		// Function getchar() to get the button pressed on the keyboard
		// If "e" is pressed, we exit while loop and the program terminate successfully.
		// Then master kills other processes
		
		// Through the use of "l" we can understand in which state we are.
		// if we are in the reset state (case 1), the system is resetting and no command can be
		// insert, except for the q command---> stop command (in case we have to stop the system in an EMERGENCY
		// during the resetting routine), until the reset has terminated. Indeed in case 0 we are in the normal situation in which 
		// we can use the Command Console, checking through a switch() which button we have entered on the keyboard.

		

		switch(l){
		
			case 1:
				printf("WAIT, COMMAND CONSOLE DISABLED!\n");
				fflush(stdout);
	        break;
	        
			// In the case 0 (normal situation) beyond printing some stuffs, we send a Signal
			// to the watchdog (VERY IMPORTANT) in orhter to reset the timer of the alarm, thanks to
			// after 60 seconds the command console will be disabled.

			case 0:

				
	        	switch(ch){

				    case 119: // case w
						printf("Z INCREASE\n");
						fflush(stdout);
						
						write(fd_to_mz, &w, sizeof(ch));
					        kill(pid_wd, SIGUSR1);
				    break;

				    case 115: // case s
						printf("Z DECREASE\n");
						fflush(stdout);
						
						write(fd_to_mz, &s, sizeof(ch));
						kill(pid_wd, SIGUSR1);
						
				    break;

				    case 122 :// case z
						printf("Z STOP\n");
						fflush(stdout);
						
						write(fd_to_mz, &z, sizeof(ch));
						kill(pid_wd, SIGUSR1);
				    break;
						
				    case 100: // case d
						printf("X INCREASE\n");
						fflush(stdout);
						
						write(fd_to_mx, &d, sizeof(ch));
						kill(pid_wd, SIGUSR1);
				    break;

				    case 97: // case a
						printf("X DECREASE\n");
						fflush(stdout);
						
						write(fd_to_mx, &a, sizeof(ch));
						kill(pid_wd, SIGUSR1);
						
				    break;

				    case 120: // case x
						printf("X STOP\n");
						fflush(stdout);
						
						write(fd_to_mx, &x, sizeof(ch));
						kill(pid_wd, SIGUSR1);
				    break;
					
					// If we press a button different from the previous one, the system will make us notice that

					//default: 
						//printf(RED "Wrong command!" RESET "\n");
						//fprintf(out, "Wrong command pressed!     Time:  %s", ctime(&current_time));
                        //fflush(out);
				    //break;
				}
			break;
		}
	}

	
	// Closing pipes

	close(fd_to_mx);
	close(fd_to_mz);
	close(fd_to_wd);
	close(fd_to_insp);

	return 0;

}
