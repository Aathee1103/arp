#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <signal.h>
#include <time.h>

/* POSITION X : 
    MINIMUM = 0
    MAXIMUM = 30 */
float x = 0;

/* COMMAND X:
    0 = Stop
    1 = Increase
    2 = Decrease
 */
int cmd,val;

//Variable for the log file

//Function to increase/decrease position with step = 0.5
//double error = (double) rand() /(double) (RAND_MAX/0.001);
float random_float(float a, float b){
    return (((float) rand())/ ((float) RAND_MAX)) * (b-a) + a;    //why random generator?- for errors
}


void execute_command(){
    if (cmd == 1) {
        if (x < 5){
            x += random_float(-0.1, 0.1);
            x += 0.1;
        } else {
            cmd = 0;
        }
    } else if (cmd == 2) {
        if (x > 0){
            x += random_float(-0.1, 0.1);
            x -= 0.1;
        } else {
            cmd = 0;
        }
    }

}

//Function to handle signals (STOP and RESET)
void handle_sigusr1(int sig){
    if (sig == SIGUSR1) {
        cmd = 5;
    }
    if (sig == SIGUSR2) {
        cmd = 2;
        
    }
}


//Function that returns a random float in the interval [a,b]


int main(int argc, char * argv[]){



    //Seeding the random number generator  //change?
    //srandom(time(NULL));

    //Get watchdog PID
    //int pid_watchdog = atoi(argv[1]);

    //Register signals
    struct sigaction sa;

    //Opening FIFOs
    int command_x, posmotor_x;    
    if ((command_x = open("/tmp/command_x", O_RDONLY)) < 0) {
        perror("MOTOR X: Error opening cmd x ");
        return 1;
    }
    if ((posmotor_x = open("/tmp/posmotor_x", O_WRONLY)) < 0) {
        perror("MOTOR X: Error opening pos x ");
        return 1;
    }


    //VARIABLES FOR SELECT
    fd_set fds;
    int retval;
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    while(1){
        memset(&sa, 0, sizeof(sa));
	sa.sa_handler=&handle_sigusr1;
	sa.sa_flags=SA_RESTART;
        sigaction(SIGUSR1, &sa, NULL);
        sigaction(SIGUSR2,&sa,NULL);
        //Reads new command from FIFO if there is a new command
        FD_ZERO(&fds);
        FD_SET(command_x, &fds);
        retval = select(FD_SETSIZE, &fds, NULL, NULL, &tv);
        if (retval < 0) {
            perror("MOTOR X: Error in select");
        } else if (retval > 0) {
            if (FD_ISSET(command_x, &fds)) {
                //reading command from FIFO
                read(command_x, &cmd, sizeof(cmd));
            }
        }

        //Increase/decrease position or stops if limit has been reached
        execute_command();

        //If it's moving sends a signal to watchdog and write new position
            //without exceeding the limit of the axes
       ///x += random_float(-0.1, 0.1);
        //kill(pid_watchdog, SIGUSR1);
        if (x > 5){
               x= 5;
             }
        if (x < 0){
               x=0;
            }            
            write(posmotor_x, &x, sizeof(x));
        sleep(1);
    }

    close(command_x);
    close(posmotor_x);
}
