#include <stdio.h>
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <time.h>


//Variables to store pid values
int pid, pid_m_x,pid_m_z,pid_wd, k_insp_pid, k_cmd_pid;

//FIFOs paths
char * command_x = "/tmp/command_x";
char * command_z = "/tmp/command_z";
char * posmotor_x = "/tmp/posmotor_x";
char * posmotor_z = "/tmp/posmotor_z";
char * comm_insp = "/tmp/comm_ins";
char * watchdog = "/tmp/cwd";

//Function to fork and execute a program
int spawn(const char * program, char ** arg_list) {
    pid_t child_pid = fork();
    if (child_pid != 0)
        return child_pid;
    else if (child_pid == 0) {
        execvp (program, arg_list);
        perror("Exec failed");
        printf("Failed to execute %s program \n", program);
        exit(1);
    } else {
        perror("Fork failed");
        return 1;
    }
}

//Exit routine, kill all processes and delete pipes
void exit_routine(){   
    kill(k_insp_pid,SIGTERM);
    kill(k_cmd_pid,SIGTERM);
    kill(pid_m_x,SIGTERM);
    kill(pid_m_z,SIGTERM);
    kill(pid_wd,SIGTERM);
    unlink(command_x);                
    unlink(command_z);                  
    unlink(posmotor_x);                  
    unlink(posmotor_z);  
}

int main() {

    //CREATING NAMED PIPES
    unlink(command_x);                  //delete if already exist
    if (mkfifo(command_x, 0666)==-1){
        perror("Error creating pipe cmd_x");
        return 1;
    }
    unlink(command_z);
    if (mkfifo(command_z, 0666)==-1){
        perror("Error creating pipe cmd_z");
        return 1;
    }
    unlink(posmotor_x);
    if (mkfifo(posmotor_x, 0666)==-1){
        perror("Error creating pipe pos_x");
        return 1;
    }
    unlink(posmotor_z);
    if (mkfifo(posmotor_z, 0666)==-1){
        perror("Error creating pipe pos_z");
        return 1;
    }
    unlink(comm_insp);
    if (mkfifo(comm_insp, 0666)==-1){
        perror("Error creating pipe pos_z");
        return 1;
    }
    unlink(watchdog);
    if (mkfifo(watchdog, 0666)==-1){
        perror("Error creating pipe pos_z");
        return 1;
    }
    
    //EXECUTE 3 PROCESSES: 2 MOTORS and WATCHDOG

    //Variables to store process pid values
    char pid_motor_x[12];
    char pid_motor_z[12];
    char pid_watchdog[12];
    
    char *arg_list_m_x[] = { "./motor_x", "/tmp/command_x", NULL };
    char *arg_list_m_z[] = { "./motor_z", "/tmp/command_z" , NULL };
	
	// fork to create various child processes 
	
    pid_m_x = spawn("./motor_x", arg_list_m_x); 
    pid_m_z = spawn("./motor_z", arg_list_m_z);

	// We convert the PIDs from integer to string, in order to succesfully 
	// pass it to the arguments of the arg_list

    sprintf(pid_motor_x, "%d", pid_m_x);
    sprintf(pid_motor_z, "%d", pid_m_z);

    char * arg_list_wacthdog[] = {"./watchdog","/tmp/cwd", pid_motor_x, pid_motor_z, (char*)NULL }; 
    pid_wd = spawn("./watchdog", arg_list_wacthdog);
    sprintf(pid_watchdog, "%d", pid_wd);
    printf("Watchdog process executed! PID = %d\n", pid_wd);   fflush(stdout); 


    //LAUNCH TWO KONSOLES: COMMAND and INSPECTION
    char * arg_list_inspection[] = {"/usr/bin/konsole", "-e", "./inspection &","/tmp/comm_ins", pid_watchdog, pid_motor_x, pid_motor_z,(char*)NULL};
    k_insp_pid = spawn( "/usr/bin/konsole", arg_list_inspection);
    printf("Ispection konsole launched! PID = %d\n", k_insp_pid);  fflush(stdout);
    
    char * arg_list_command[] = {"/usr/bin/konsole", "-e", "./command &", pid_watchdog, (char*)NULL};
    k_cmd_pid = spawn("/usr/bin/konsole", arg_list_command);
    printf("Control konsole launched! PID = %d\n", k_cmd_pid);  fflush(stdout);



    // Parent process waits here for command to terminate all other processes

    //EXIT
    return 0;

}
